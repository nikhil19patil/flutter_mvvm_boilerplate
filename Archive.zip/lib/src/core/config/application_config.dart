part of condig_lib;

class _ApplicationConfig {
  _ApplicationConfig(Map<String, dynamic> config);
}
