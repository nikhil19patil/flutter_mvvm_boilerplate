class ApiUrls {
  // For Login
  static const String login = '/auth/login';

  // For Registration
  // static const String registration = '/user/createUser';
}
