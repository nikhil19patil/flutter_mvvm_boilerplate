import 'package:flutter/material.dart';
import 'package:illumine/mvvm/models/login_module/login_response_model.dart';
import 'package:illumine/mvvm/view_models/asssessment/assessment_view_model.dart';
import 'package:illumine/mvvm/view_models/login_module/forgot_password_view_model.dart';
import 'package:illumine/mvvm/view_models/login_module/login_view_model.dart';
import 'package:illumine/mvvm/view_models/login_module/registration_view_model.dart';
import 'package:illumine/providers/auth_provider.dart';
import 'package:illumine/providers/user_provider.dart';
import 'package:illumine/utility/route_generator.dart';
import 'package:illumine/utility/shared_preference.dart';
import 'package:provider/provider.dart';

import 'mvvm/view_models/dashboard/dashbord_view_model.dart';
import 'src/core/config/size_config.dart';

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    Future<LoginResponseModel>? getUserData() => SharedPref().getUser();

    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LoginViewModel()),
        ChangeNotifierProvider(create: (_) => RegistrationViewModel()),
        ChangeNotifierProvider(create: (_) => ForgotPasswordViewModel()),
        ChangeNotifierProvider(create: (_) => RegistrationViewModel()),
        ChangeNotifierProvider(create: (_) => ForgotPasswordViewModel()),
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => UserProvider()),
        ChangeNotifierProvider(create: (_) => AssesmentViewModel()),
        ChangeNotifierProvider(create: (_) => DashboardViewModel())
      ],
      child: LayoutBuilder(
        builder: (context, constraints) {
          return OrientationBuilder(
            builder: (context, orientation) {
              SizeConfig().init(constraints, orientation);
              return const MaterialApp(
                debugShowCheckedModeBanner: false,
                initialRoute: RouteConstants.kSplashScreen,
                onGenerateRoute: RouteGenerator.generateRoute,
              );
            },
          );
        },
      ),
    );
  }
}
