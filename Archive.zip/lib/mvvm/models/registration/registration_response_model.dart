class RegistrationResponse {
  User? user;
  Tokens? tokens;
  int? code;
  String? message;

  RegistrationResponse({this.user, this.tokens, this.code, this.message});

  RegistrationResponse.fromJson(Map<String, dynamic> json) {
    user = json['user'] != null ? User.fromJson(json['user']) : null;
    tokens = json['tokens'] != null ? Tokens.fromJson(json['tokens']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    if (user != null) {
      data['user'] = user?.toJson();
    }
    if (tokens != null) {
      data['tokens'] = tokens?.toJson();
    }
    return data;
  }
}

class User {
  String? id;
  String? email;
  String? fullname;
  List<String>? role;
  String? organizationid;
  String? prepareFlag;
  String? conductFlag;
  String? exploreFlag;
  List<String>? effectiveAccessRights;

  User(
      {this.id,
      this.email,
      this.fullname,
      this.role,
      this.organizationid,
      this.prepareFlag,
      this.conductFlag,
      this.exploreFlag,
      this.effectiveAccessRights});

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    email = json['email'];
    fullname = json['fullname'];
    if (json['role'] != null) {
      role = json['role'].cast<String>();
    }
    organizationid = json['organizationid'];
    prepareFlag = json['prepareFlag'];
    conductFlag = json['conductFlag'];
    exploreFlag = json['exploreFlag'];
    if (json['effective_access_rights'] != null) {
      effectiveAccessRights = json['effective_access_rights'].cast<String>();
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['id'] = this.id;
    data['email'] = this.email;
    data['fullname'] = this.fullname;
    if (this.role != null) {
      data['role'] = this.role;
    }
    data['organizationid'] = this.organizationid;
    data['prepareFlag'] = this.prepareFlag;
    data['conductFlag'] = this.conductFlag;
    data['exploreFlag'] = this.exploreFlag;
    if (this.effectiveAccessRights != null) {
      data['effective_access_rights'] = this.effectiveAccessRights;
    }
    return data;
  }
}

class Tokens {
  Access? access;
  Access? refresh;

  Tokens({this.access, this.refresh});

  Tokens.fromJson(Map<String, dynamic> json) {
    access = json['access'] != null ? Access.fromJson(json['access']) : null;
    refresh = json['refresh'] != null ? Access.fromJson(json['refresh']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    if (this.access != null) {
      data['access'] = this.access?.toJson();
    }
    if (this.refresh != null) {
      data['refresh'] = this.refresh?.toJson();
    }
    return data;
  }
}

class Access {
  String? token;
  String? expires;

  Access({this.token, this.expires});

  Access.fromJson(Map<String, dynamic> json) {
    token = json['token'];
    expires = json['expires'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['token'] = this.token;
    data['expires'] = this.expires;
    return data;
  }
}
