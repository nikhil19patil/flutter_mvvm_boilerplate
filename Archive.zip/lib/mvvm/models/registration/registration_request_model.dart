/// email : "test5.analytics@gmail.com"
/// password : "Test@123"
/// fullname : "Test"
/// accesscode : "ANALYTICS_COLLEGE"

class RegistrationRequestModel {
  RegistrationRequestModel({
    String? email,
    String? password,
    String? fullname,
    String? accesscode,
  }) {
    _email = email;
    _password = password;
    _fullname = fullname;
    _accesscode = accesscode;
  }

  RegistrationRequestModel.fromJson(dynamic json) {
    _email = json['email'];
    _password = json['password'];
    _fullname = json['fullname'];
    _accesscode = json['accesscode'];
  }
  String? _email;
  String? _password;
  String? _fullname;
  String? _accesscode;

  String? get email => _email;
  String? get password => _password;
  String? get fullname => _fullname;
  String? get accesscode => _accesscode;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['email'] = _email;
    map['password'] = _password;
    map['fullname'] = _fullname;
    map['accesscode'] = _accesscode;
    return map;
  }
}
