class AssessmentResponseModel {
  AssessmentResponseModel({
    List<String>? testInstructions,
    List<Questions>? questions,
    String? id,
    String? moduleId,
    String? testType,
    String? testTitle,
    //String? id,
  }) {
    _testInstructions = testInstructions;
    _questions = questions;
    _id = id;
    _moduleId = moduleId;
    _testType = testType;
    _testTitle = testTitle;
    //_id = id;
  }

  AssessmentResponseModel.fromJson(dynamic json) {
    _testInstructions = json['testInstructions'] != null
        ? json['testInstructions'].cast<String>()
        : [];
    if (json['questions'] != null) {
      _questions = [];
      json['questions'].forEach((v) {
        _questions?.add(Questions.fromJson(v));
      });
    }
    _id = json['_id'];
    _moduleId = json['moduleId'];
    _testType = json['testType'];
    _testTitle = json['testTitle'];
    //_id = json['id'];
  }
  List<String>? _testInstructions;
  List<Questions>? _questions;
  String? _id;
  String? _moduleId;
  String? _testType;
  String? _testTitle;
  //String? _id;

  List<String>? get testInstructions => _testInstructions;
  List<Questions>? get questions => _questions;
  String? get id => _id;
  String? get moduleId => _moduleId;
  String? get testType => _testType;
  String? get testTitle => _testTitle;
  //String? get id => _id;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['testInstructions'] = _testInstructions;
    if (_questions != null) {
      map['questions'] = _questions?.map((v) => v.toJson()).toList();
    }
    map['_id'] = _id;
    map['moduleId'] = _moduleId;
    map['testType'] = _testType;
    map['testTitle'] = _testTitle;
    // map['id'] = _id;
    return map;
  }
}

/// _id : "5faaee06f4e3713bf04b0f09"
/// question : "Which of the following is not a function of management"
/// answers : [{"option":"staffing"},{"option":"planning","src":"https://th.bing.com/th/id/R.a01c96de1c8f0c10dd40fd28f0e2d786?rik=JyXtrBw0i7awYA&riu=http%3a%2f%2fwww.brightlinkprep.com%2fwp-content%2fuploads%2f2014%2f04%2fsample.jpg&ehk=9GofGDpb3peoKRIAFbxWC8%2fFRusf6r3kg9exEidIItg%3d&risl=&pid=ImgRaw&r=0"},{"option":"controlling"},{"option":"co-operation"}]
/// dimension : "5fc3de3991d9df247849fe25"
/// id : "5faaee06f4e3713bf04b0f09"

class Questions {
  Questions({
    String? id,
    String? question,
    List<Answers>? answers,
    String? dimension,
    //String? id,
  }) {
    _id = id;
    _question = question;
    _answers = answers;
    _dimension = dimension;
    //_id = id;
  }

  Questions.fromJson(dynamic json) {
    _id = json['_id'];
    _question = json['question'];
    if (json['answers'] != null) {
      _answers = [];
      json['answers'].forEach((v) {
        _answers?.add(Answers.fromJson(v));
      });
    }
    _dimension = json['dimension'];
    //_id = json['id'];
  }
  String? _id;
  String? _question;
  List<Answers>? _answers;
  String? _dimension;
  //String? _id;

  String? get id => _id;
  String? get question => _question;
  List<Answers>? get answers => _answers;
  String? get dimension => _dimension;
  //String? get id => _id;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['_id'] = _id;
    map['question'] = _question;
    if (_answers != null) {
      map['answers'] = _answers?.map((v) => v.toJson()).toList();
    }
    map['dimension'] = _dimension;
    //map['id'] = _id;
    return map;
  }
}

/// option : "staffing"

class Answers {
  Answers({
    String? option,
  }) {
    _option = option;
  }

  Answers.fromJson(dynamic json) {
    _option = json['option'];
  }
  String? _option;

  String? get option => _option;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['option'] = _option;
    return map;
  }
}
