class AssessmentRequestModel {
  final String moduleId;

  AssessmentRequestModel({required this.moduleId});

  factory AssessmentRequestModel.fromJson(Map<String, dynamic> json) {
    return AssessmentRequestModel(moduleId: json["moduleid"]);
  }

  Map<String, dynamic> toMap() => {"moduleid": moduleId};
}
