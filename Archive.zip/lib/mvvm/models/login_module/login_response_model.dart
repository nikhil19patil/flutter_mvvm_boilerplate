/// user : {"id":"61656f675ba330002f2e67a7","email":"test@joshsoftware.com","fullname":"Josh Test","role":[{"dashboard":[],"user_right":["allow_class","allow_daily_gym","allow_revice"],"_id":"5ea5db7fb772635fc83769e1","rolename":"Student","createdAt":"2020-04-26T19:05:35.821Z","updatedAt":"2020-04-26T19:05:35.821Z","__v":0,"id":"5ea5db7fb772635fc83769e1"},{"dashboard":[],"user_right":["allow_daily_gym","allow_prepare"],"_id":"5eb67a502d0bd735a8ff15a8","rolename":"Coach","createdAt":"2020-05-09T09:39:28.650Z","updatedAt":"2020-05-09T09:39:28.650Z","__v":0,"id":"5eb67a502d0bd735a8ff15a8"}],"organizationid":"61656effb35631eb1258bbe6","prepareFlag":"0","conductFlag":"0","exploreFlag":"0","effective_access_rights":["allow_class","allow_daily_gym","allow_revice","allow_prepare"]}
/// tokens : {"access":{"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2MTY1NmY2NzViYTMzMDAwMmYyZTY3YTciLCJpYXQiOjE2NDAzNDA5NjAsImV4cCI6MTY1NTg5Mjk2MH0.HOlZIRT8keIN1v9WRbHbycUsJCUNYUWq-EH7H_nglmA","expires":"2022-06-22T10:16:00.853Z"},"refresh":{"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2MTY1NmY2NzViYTMzMDAwMmYyZTY3YTciLCJpYXQiOjE2NDAzNDA5NjAsImV4cCI6MTY0NTUyNDk2MH0.6lcgi6FN9LK3QmyE6xaRWsgbKNcEMSpxJvuGdKaJ4a8","expires":"2022-02-22T10:16:00.854Z"}}

class LoginResponseModel {
  LoginResponseModel({
    User? user,
    Tokens? tokens,
  }) {
    _user = user;
    _tokens = tokens;
  }

  LoginResponseModel.fromJson(dynamic json) {
    _user = json['user'] != null ? User.fromJson(json['user']) : null;
    _tokens = json['tokens'] != null ? Tokens.fromJson(json['tokens']) : null;
  }
  User? _user;
  Tokens? _tokens;

  User? get user => _user;
  Tokens? get tokens => _tokens;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_user != null) {
      map['user'] = _user?.toJson();
    }
    if (_tokens != null) {
      map['tokens'] = _tokens?.toJson();
    }
    return map;
  }
}

/// access : {"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2MTY1NmY2NzViYTMzMDAwMmYyZTY3YTciLCJpYXQiOjE2NDAzNDA5NjAsImV4cCI6MTY1NTg5Mjk2MH0.HOlZIRT8keIN1v9WRbHbycUsJCUNYUWq-EH7H_nglmA","expires":"2022-06-22T10:16:00.853Z"}
/// refresh : {"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2MTY1NmY2NzViYTMzMDAwMmYyZTY3YTciLCJpYXQiOjE2NDAzNDA5NjAsImV4cCI6MTY0NTUyNDk2MH0.6lcgi6FN9LK3QmyE6xaRWsgbKNcEMSpxJvuGdKaJ4a8","expires":"2022-02-22T10:16:00.854Z"}

class Tokens {
  Tokens({
    Access? access,
    Refresh? refresh,
  }) {
    _access = access;
    _refresh = refresh;
  }

  Tokens.fromJson(dynamic json) {
    _access = json['access'] != null ? Access.fromJson(json['access']) : null;
    _refresh =
        json['refresh'] != null ? Refresh.fromJson(json['refresh']) : null;
  }
  Access? _access;
  Refresh? _refresh;

  Access? get access => _access;
  Refresh? get refresh => _refresh;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_access != null) {
      map['access'] = _access?.toJson();
    }
    if (_refresh != null) {
      map['refresh'] = _refresh?.toJson();
    }
    return map;
  }
}

/// token : "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2MTY1NmY2NzViYTMzMDAwMmYyZTY3YTciLCJpYXQiOjE2NDAzNDA5NjAsImV4cCI6MTY0NTUyNDk2MH0.6lcgi6FN9LK3QmyE6xaRWsgbKNcEMSpxJvuGdKaJ4a8"
/// expires : "2022-02-22T10:16:00.854Z"

class Refresh {
  Refresh({
    String? token,
    String? expires,
  }) {
    _token = token;
    _expires = expires;
  }

  Refresh.fromJson(dynamic json) {
    _token = json['token'];
    _expires = json['expires'];
  }
  String? _token;
  String? _expires;

  String? get token => _token;
  String? get expires => _expires;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['token'] = _token;
    map['expires'] = _expires;
    return map;
  }
}

/// token : "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2MTY1NmY2NzViYTMzMDAwMmYyZTY3YTciLCJpYXQiOjE2NDAzNDA5NjAsImV4cCI6MTY1NTg5Mjk2MH0.HOlZIRT8keIN1v9WRbHbycUsJCUNYUWq-EH7H_nglmA"
/// expires : "2022-06-22T10:16:00.853Z"

class Access {
  Access({
    String? token,
    String? expires,
  }) {
    _token = token;
    _expires = expires;
  }

  Access.fromJson(dynamic json) {
    _token = json['token'];
    _expires = json['expires'];
  }
  String? _token;
  String? _expires;

  String? get token => _token;
  String? get expires => _expires;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['token'] = _token;
    map['expires'] = _expires;
    return map;
  }
}

/// id : "61656f675ba330002f2e67a7"
/// email : "test@joshsoftware.com"
/// fullname : "Josh Test"
/// role : [{"dashboard":[],"user_right":["allow_class","allow_daily_gym","allow_revice"],"_id":"5ea5db7fb772635fc83769e1","rolename":"Student","createdAt":"2020-04-26T19:05:35.821Z","updatedAt":"2020-04-26T19:05:35.821Z","__v":0,"id":"5ea5db7fb772635fc83769e1"},{"dashboard":[],"user_right":["allow_daily_gym","allow_prepare"],"_id":"5eb67a502d0bd735a8ff15a8","rolename":"Coach","createdAt":"2020-05-09T09:39:28.650Z","updatedAt":"2020-05-09T09:39:28.650Z","__v":0,"id":"5eb67a502d0bd735a8ff15a8"}]
/// organizationid : "61656effb35631eb1258bbe6"
/// prepareFlag : "0"
/// conductFlag : "0"
/// exploreFlag : "0"
/// effective_access_rights : ["allow_class","allow_daily_gym","allow_revice","allow_prepare"]

class User {
  User({
    String? id,
    String? email,
    String? fullname,
    List<Role>? role,
    String? organizationid,
    String? prepareFlag,
    String? conductFlag,
    String? exploreFlag,
    List<String>? effectiveAccessRights,
  }) {
    _id = id;
    _email = email;
    _fullname = fullname;
    _role = role;
    _organizationid = organizationid;
    _prepareFlag = prepareFlag;
    _conductFlag = conductFlag;
    _exploreFlag = exploreFlag;
    _effectiveAccessRights = effectiveAccessRights;
  }

  User.fromJson(dynamic json) {
    _id = json['id'];
    _email = json['email'];
    _fullname = json['fullname'];
    if (json['role'] != null) {
      _role = [];
      json['role'].forEach((v) {
        _role?.add(Role.fromJson(v));
      });
    }
    _organizationid = json['organizationid'];
    _prepareFlag = json['prepareFlag'];
    _conductFlag = json['conductFlag'];
    _exploreFlag = json['exploreFlag'];
    _effectiveAccessRights = json['effective_access_rights'] != null
        ? json['effective_access_rights'].cast<String>()
        : [];
  }
  String? _id;
  String? _email;
  String? _fullname;
  List<Role>? _role;
  String? _organizationid;
  String? _prepareFlag;
  String? _conductFlag;
  String? _exploreFlag;
  List<String>? _effectiveAccessRights;

  String? get id => _id;
  String? get email => _email;
  String? get fullname => _fullname;
  List<Role>? get role => _role;
  String? get organizationid => _organizationid;
  String? get prepareFlag => _prepareFlag;
  String? get conductFlag => _conductFlag;
  String? get exploreFlag => _exploreFlag;
  List<String>? get effectiveAccessRights => _effectiveAccessRights;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['email'] = _email;
    map['fullname'] = _fullname;
    if (_role != null) {
      map['role'] = _role?.map((v) => v.toJson()).toList();
    }
    map['organizationid'] = _organizationid;
    map['prepareFlag'] = _prepareFlag;
    map['conductFlag'] = _conductFlag;
    map['exploreFlag'] = _exploreFlag;
    map['effective_access_rights'] = _effectiveAccessRights;
    return map;
  }
}

/// dashboard : []
/// user_right : ["allow_class","allow_daily_gym","allow_revice"]
/// _id : "5ea5db7fb772635fc83769e1"
/// rolename : "Student"
/// createdAt : "2020-04-26T19:05:35.821Z"
/// updatedAt : "2020-04-26T19:05:35.821Z"
/// __v : 0
/// id : "5ea5db7fb772635fc83769e1"

class Role {
  Role({
    //List<dynamic>? dashboard,
    List<String>? userRight,
    String? id,
    String? rolename,
    String? createdAt,
    String? updatedAt,
    int? v,
    //String? id,
  }) {
    //_dashboard = dashboard;
    _userRight = userRight;
    _id = id;
    _rolename = rolename;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
    _v = v;
    //_id = id;
  }

  Role.fromJson(dynamic json) {
    // if (json['dashboard'] != null) {
    //   _dashboard = [];
    //   json['dashboard'].forEach((v) {
    //     _dashboard?.add(dynamic.fromJson(v));
    //   });
    // }
    _userRight =
        json['user_right'] != null ? json['user_right'].cast<String>() : [];
    _id = json['_id'];
    _rolename = json['rolename'];
    _createdAt = json['createdAt'];
    _updatedAt = json['updatedAt'];
    _v = json['__v'];
    //_id = json['id'];
  }
  //List<dynamic>? _dashboard;
  List<String>? _userRight;
  String? _id;
  String? _rolename;
  String? _createdAt;
  String? _updatedAt;
  int? _v;
  //String? _id;

  //List<dynamic>? get dashboard => _dashboard;
  List<String>? get userRight => _userRight;
  String? get id => _id;
  String? get rolename => _rolename;
  String? get createdAt => _createdAt;
  String? get updatedAt => _updatedAt;
  int? get v => _v;
  //String? get id => _id;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    // if (_dashboard != null) {
    //   map['dashboard'] = _dashboard?.map((v) => v.toJson()).toList();
    // }
    map['user_right'] = _userRight;
    map['_id'] = _id;
    map['rolename'] = _rolename;
    map['createdAt'] = _createdAt;
    map['updatedAt'] = _updatedAt;
    map['__v'] = _v;
    //map['id'] = _id;
    return map;
  }
}
