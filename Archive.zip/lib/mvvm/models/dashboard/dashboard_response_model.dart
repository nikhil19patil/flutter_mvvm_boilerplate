/// card : [{"_id":"61657cef6d5d400030224e4f","title":{"title":"LIVE CLASS ALERT!","description":"for 'Starmaker Madurai'","src":"https://picsum.photos/38"},"description":"LEARNING HOUR 2: What happens when I become a StarMaker?","icon":"https://picsum.photos/330/182","expiredOn":"2021-12-25T12:58:15.722Z","sessionStartTime":"2021-12-25T12:58:15.722Z","cta":[{"title":"Connect to LIVE CLASS 17 Dec","action":{"url":"deep link to component"}}],"remark":"Earn upto 10 certification points!","status":"unread"},{"_id":"61657cef6d5d400030224e4g","title":{"title":"DAILY FLASHPOINT GYM","description":" Situation 2/60","src":"https://picsum.photos/38"},"description":"The Customer has requests for appointment at abnormal times","icon":"https://picsum.photos/330/182","expiredOn":"2021-12-25T12:58:15.722Z","cta":[{"title":"Learn how you can convince the customer","action":{"url":"deep link to component"}}],"remark":"Earn upto 10 certification points!","status":"unread"}]
/// service : [{"title":"Classes","icon":"https://picsum.photos/200","color":"#FF0000","text":"Attendance of classes","x/y":"2/2"},{"title":"Track Growth","icon":"https://picsum.photos/200","color":"#00FF00","text":"Going Good"}]

class DashboardResponseModel {
  DashboardResponseModel({
    List<AppCard>? card,
    List<Service>? service,
  }) {
    _card = card;
    _service = service;
  }

  DashboardResponseModel.fromJson(dynamic json) {
    if (json['card'] != null) {
      _card = [];
      json['card'].forEach((v) {
        _card?.add(AppCard.fromJson(v));
      });
    }
    if (json['service'] != null) {
      _service = [];
      json['service'].forEach((v) {
        _service?.add(Service.fromJson(v));
      });
    }
  }
  List<AppCard>? _card;
  List<Service>? _service;

  List<AppCard>? get card => _card;
  List<Service>? get service => _service;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_card != null) {
      map['card'] = _card?.map((v) => v.toJson()).toList();
    }
    if (_service != null) {
      map['service'] = _service?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// title : "Classes"
/// icon : "https://picsum.photos/200"
/// color : "#FF0000"
/// text : "Attendance of classes"
/// x/y : "2/2"

class Service {
  Service({
    String? title,
    String? icon,
    String? color,
    String? text,
  }) {
    _title = title;
    _icon = icon;
    _color = color;
    _text = text;
  }

  Service.fromJson(dynamic json) {
    _title = json['title'];
    _icon = json['icon'];
    _color = json['color'];
    _text = json['text'];
  }
  String? _title;
  String? _icon;
  String? _color;
  String? _text;

  String? get title => _title;
  String? get icon => _icon;
  String? get color => _color;
  String? get text => _text;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = _title;
    map['icon'] = _icon;
    map['color'] = _color;
    map['text'] = _text;
    return map;
  }
}

/// _id : "61657cef6d5d400030224e4f"
/// title : {"title":"LIVE CLASS ALERT!","description":"for 'Starmaker Madurai'","src":"https://picsum.photos/38"}
/// description : "LEARNING HOUR 2: What happens when I become a StarMaker?"
/// icon : "https://picsum.photos/330/182"
/// expiredOn : "2021-12-25T12:58:15.722Z"
/// sessionStartTime : "2021-12-25T12:58:15.722Z"
/// cta : [{"title":"Connect to LIVE CLASS 17 Dec","action":{"url":"deep link to component"}}]
/// remark : "Earn upto 10 certification points!"
/// status : "unread"

class AppCard {
  AppCard({
    String? id,
    Title? title,
    String? description,
    String? icon,
    String? expiredOn,
    String? sessionStartTime,
    List<Cta>? cta,
    String? remark,
    String? status,
  }) {
    _id = id;
    _title = title;
    _description = description;
    _icon = icon;
    _expiredOn = expiredOn;
    _sessionStartTime = sessionStartTime;
    _cta = cta;
    _remark = remark;
    _status = status;
  }

  AppCard.fromJson(dynamic json) {
    _id = json['_id'];
    _title = json['title'] != null ? Title.fromJson(json['title']) : null;
    _description = json['description'];
    _icon = json['icon'];
    _expiredOn = json['expiredOn'];
    _sessionStartTime = json['sessionStartTime'];
    if (json['cta'] != null) {
      _cta = [];
      json['cta'].forEach((v) {
        _cta?.add(Cta.fromJson(v));
      });
    }
    _remark = json['remark'];
    _status = json['status'];
  }
  String? _id;
  Title? _title;
  String? _description;
  String? _icon;
  String? _expiredOn;
  String? _sessionStartTime;
  List<Cta>? _cta;
  String? _remark;
  String? _status;

  String? get id => _id;
  Title? get title => _title;
  String? get description => _description;
  String? get icon => _icon;
  String? get expiredOn => _expiredOn;
  String? get sessionStartTime => _sessionStartTime;
  List<Cta>? get cta => _cta;
  String? get remark => _remark;
  String? get status => _status;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['_id'] = _id;
    if (_title != null) {
      map['title'] = _title?.toJson();
    }
    map['description'] = _description;
    map['icon'] = _icon;
    map['expiredOn'] = _expiredOn;
    map['sessionStartTime'] = _sessionStartTime;
    if (_cta != null) {
      map['cta'] = _cta?.map((v) => v.toJson()).toList();
    }
    map['remark'] = _remark;
    map['status'] = _status;
    return map;
  }
}

/// title : "Connect to LIVE CLASS 17 Dec"
/// action : {"url":"deep link to component"}

class Cta {
  Cta({
    String? title,
    Action? action,
  }) {
    _title = title;
    _action = action;
  }

  Cta.fromJson(dynamic json) {
    _title = json['title'];
    _action = json['action'] != null ? Action.fromJson(json['action']) : null;
  }
  String? _title;
  Action? _action;

  String? get title => _title;
  Action? get action => _action;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = _title;
    if (_action != null) {
      map['action'] = _action?.toJson();
    }
    return map;
  }
}

/// url : "deep link to component"

class Action {
  Action({
    String? url,
  }) {
    _url = url;
  }

  Action.fromJson(dynamic json) {
    _url = json['url'];
  }
  String? _url;

  String? get url => _url;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['url'] = _url;
    return map;
  }
}

/// title : "LIVE CLASS ALERT!"
/// description : "for 'Starmaker Madurai'"
/// src : "https://picsum.photos/38"

class Title {
  Title({
    String? title,
    String? description,
    String? src,
  }) {
    _title = title;
    _description = description;
    _src = src;
  }

  Title.fromJson(dynamic json) {
    _title = json['title'];
    _description = json['description'];
    _src = json['src'];
  }
  String? _title;
  String? _description;
  String? _src;

  String? get title => _title;
  String? get description => _description;
  String? get src => _src;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = _title;
    map['description'] = _description;
    map['src'] = _src;
    return map;
  }
}

//-------
/*
{
    "card": [
        {
            "_id": "61657cef6d5d400030224e4f",
            "title": {
                "title": "LIVE CLASS ALERT!",
                "description": "for 'Starmaker Madurai'",
                "src": "https://picsum.photos/38"
            },
            "description": "LEARNING HOUR 2: What happens when I become a StarMaker?",
            "icon": "https://picsum.photos/330/182",
            "expiredOn": "2021-12-26T07:13:57.655Z",
            "sessionStartTime": "2021-12-26T07:13:57.655Z",
            "cta": [
                {
                    "title": "Connect to LIVE CLASS 17 Dec",
                    "action": {
                        "url": "deep link to component"
                    }
                }
            ],
            "remark": "Earn upto 10 certification points!",
            "status": "unread"
        },
        {
            "_id": "61657cef6d5d400030224e4g",
            "title": {
                "title": "DAILY FLASHPOINT GYM",
                "description": " Situation 2/60",
                "src": "https://picsum.photos/38"
            },
            "description": "The Customer has requests for appointment at abnormal times",
            "icon": "https://picsum.photos/330/182",
            "expiredOn": "2021-12-26T07:13:57.655Z",
            "cta": [
                {
                    "title": "Learn how you can convince the customer",
                    "action": {
                        "url": "deep link to component"
                    }
                }
            ],
            "remark": "Earn upto 10 certification points!",
            "status": "unread"
        }
    ],
    "service": [
        {
            "title": "Classes",
            "icon": "https://picsum.photos/200",
            "color": "#FF0000",
            "text": "Attendance of classes",
            "x/y": "2/2"
        },
        {
            "title": "Track Growth",
            "icon": "https://picsum.photos/200",
            "color": "#00FF00",
            "text": "Going Good"
        }
    ]
}
 */
