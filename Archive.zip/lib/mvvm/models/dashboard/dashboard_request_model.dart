class DasboardRequestModel {
  DasboardRequestModel({
    String? studentId,
  }) {
    _studentId = studentId;
  }

  DasboardRequestModel.fromJson(dynamic json) {
    _studentId = json['studentId'];
  }
  String? _studentId;

  String? get studentId => _studentId;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['studentId'] = _studentId;
    return map;
  }
}

/*

 {
    "studentId": "61657cef6d5d400030224e4f"
}
 */
