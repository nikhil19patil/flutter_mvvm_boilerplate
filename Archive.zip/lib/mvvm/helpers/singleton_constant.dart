import 'package:illumine/mvvm/models/login_module/login_response_model.dart';
import 'package:illumine/src/core/value/Constants.dart';
import 'package:illumine/utility/shared_preference.dart';

import 'api_constants.dart';

class SingletonConstants {
  static final SingletonConstants _singleton = SingletonConstants._internal();

  factory SingletonConstants() {
    return _singleton;
  }

  SingletonConstants._internal();

  String _baseUrl = "";
  String _authToken = "";
  late LoginResponseModel _loginResponseModel;

  User? getLoggedInUser() => _loginResponseModel.user;

  String getBaseUrl() =>
      _baseUrl != "" ? _baseUrl : ApiConstants.SERVER_BASE_URL;

  void setBaseUrl(String baseURL) => _baseUrl = baseURL;

  Future<String> get getToken async {
    if (_authToken != "") {
      return _authToken;
    } else {
      _authToken =
          await SharedPref().read(Constants.kSharedPrefConstant.kAuthToken) ??
              "";
    }
    return _authToken;
  }

  void setUser(LoginResponseModel model) => _loginResponseModel = model;

  // Future<User> get getLoggedInUser()  {
  //   if (_loginResponseModel != null) {
  //     return _loginResponseModel.user;
  //   }
  //   else {
  //     _loginResponseModel =
  //         await SharedPref().read(Constants.kSharedPrefConstant.kUserModel);
  //     return _loginResponseModel?.user;
  //   }
  // }

}
