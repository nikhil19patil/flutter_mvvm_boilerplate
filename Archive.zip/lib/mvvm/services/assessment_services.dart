import 'package:flutter/material.dart';
import 'package:illumine/mvvm/Helpers/api_constants.dart';
import 'package:illumine/mvvm/Helpers/api_helper.dart';
import 'package:illumine/mvvm/models/Common/response_data_model.dart';
import 'package:illumine/mvvm/models/assessment/assessment_request_model.dart';

class AssessmentService {
  Future<ResponseData> getAssesmentData(
      {required BuildContext context,
      required AssessmentRequestModel assessmentRequestModel,
      required bool logInWithCommonLoader}) {
    Uri _uri = Uri.parse(baseURL + ApiConstants.GetAssesmentData);

    return ApiHelper().postRequest(
        context, _uri, assessmentRequestModel.toMap(),
        useAuth: true,
        showLoader: logInWithCommonLoader,
        responseName: "get assesment data",
        showLog: true,
        showError: true);
  }
}
