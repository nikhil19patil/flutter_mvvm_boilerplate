import 'package:flutter/material.dart';
import 'package:illumine/mvvm/Helpers/api_helper.dart';
import 'package:illumine/mvvm/helpers/api_constants.dart';
import 'package:illumine/mvvm/models/Common/response_data_model.dart';
import 'package:illumine/mvvm/models/forgot_password/forgot_password_request_model.dart';
import 'package:illumine/mvvm/models/login_module/login_request_model.dart';
import 'package:illumine/mvvm/models/registration/registration_request_model.dart';
import 'package:illumine/mvvm/models/registration/registration_request_model.dart';
import 'package:illumine/mvvm/models/registration/registration_request_model.dart';

class LoginService {
  Future<ResponseData> loginUser(
      {required BuildContext context,
      required LoginRequestModel loginModel,
      required bool logInWithCommonLoader}) {
    //final String _loginApiUrl = EnvironmentConfig.baseUrl + ApiUrls.login;
    //Uri _uri = Uri.parse(_loginApiUrl);

    Uri _uri = Uri.parse(baseURL + ApiConstants.LOGIN);

    return ApiHelper().postRequest(context, _uri, loginModel.toMap(),
        useAuth: false,
        showLoader: logInWithCommonLoader,
        responseName: "Login",
        showLog: true,
        showError: true);
  }

  //register API
  Future<ResponseData> registerUser(
      {required BuildContext context,
      required RegistrationRequestModel registrationRequestModel,
      required bool commonLoader}) {
    //final String _loginApiUrl = EnvironmentConfig.baseUrl + ApiUrls.login;
    //Uri _uri = Uri.parse(_loginApiUrl);

    Uri _uri = Uri.parse(baseURL + ApiConstants.REGISTER);

    return ApiHelper().postRequest(
        context, _uri, registrationRequestModel.toJson(),
        useAuth: false,
        showLoader: commonLoader,
        responseName: "Register",
        showLog: true,
        showError: true);
  }

//forgot password API
  Future<ResponseData> forgotPassword(
      {required BuildContext context,
        required ForgotPasswordRequestModel forgotPasswordRequestModel,
        required bool commonLoader}) {
    //final String _loginApiUrl = EnvironmentConfig.baseUrl + ApiUrls.login;
    //Uri _uri = Uri.parse(_loginApiUrl);

    Uri _uri = Uri.parse(baseURL + ApiConstants.FORGOT_PASSWORD);

    return ApiHelper().postRequest(context, _uri, forgotPasswordRequestModel.toJson(),
        useAuth: false,
        showLoader: commonLoader,
        responseName: "Register",
        showLog: true,
        showError: true);
  }

//logout API

}
