import 'package:flutter/material.dart';
import 'package:illumine/mvvm/helpers/api_constants.dart';
import 'package:illumine/mvvm/helpers/api_helper.dart';
import 'package:illumine/mvvm/models/Common/response_data_model.dart';
import 'package:illumine/mvvm/models/dashboard/dashboard_request_model.dart';

class DashboardServices {
  Future<ResponseData> getCardsAndServices(
      {required BuildContext context,
      required DasboardRequestModel model,
      required bool isUseCommonLoader}) {
    //'https://uatapi.pedgog.in/v1/student/card/61657cef6d5d400030224e4f'
    final StrUrl = baseURL +
        ApiConstants.DashbordGetCardsAndServices +
        "${model.studentId}";

    Uri _uri = Uri.parse(StrUrl);

    return ApiHelper().getRequest(context, _uri,
        useAuth: true,
        showLoader: isUseCommonLoader,
        responseName: "Dashboard",
        showLog: true,
        showError: true);
  }
}

/*
var request = http.Request('GET', Uri.parse('https://uatapi.pedgog.in/v1/student/card/61657cef6d5d400030224e4f'));
 */
