import 'package:flutter/material.dart';
import 'package:illumine/mvvm/Helpers/api_helper.dart';
import 'package:illumine/mvvm/models/assessment/assessment_response_model.dart';
import 'package:illumine/mvvm/view_models/asssessment/assessment_view_model.dart';
import 'package:illumine/src/core/value/Constants.dart';
import 'package:illumine/src/core/value/colors.dart';
import 'package:illumine/utility/route_generator.dart';
import 'package:provider/provider.dart';

class AssesmentScreen extends StatefulWidget {
  const AssesmentScreen({Key? key}) : super(key: key);

  @override
  _AssesmentScreenState createState() => _AssesmentScreenState();
}

class _AssesmentScreenState extends State<AssesmentScreen> {
  late AssesmentViewModel _assesmentViewModel;
  late Future<AssessmentResponseModel> _response;

  @override
  void initState() {
    super.initState();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _assesmentViewModel =
        Provider.of<AssesmentViewModel>(context, listen: false);
    _response = _assesmentViewModel.getAssessmentData(context: context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _customAppBar(),
      body: SafeArea(
        child: FutureBuilder(
            future: _response,
            builder: (context, snapshot) {
              switch (snapshot.connectionState) {
                case ConnectionState.none:
                case ConnectionState.waiting:
                  return const Center();

                default:
                  return const AssesmentQuestionView();
              }
            }),
      ),
    );
  }

  AppBar _customAppBar() {
    return AppBar(
      elevation: 0,
      backgroundColor: Colors.white,
      foregroundColor: Colors.black,
      actions: [
        Stack(
          children: <Widget>[
            IconButton(
                icon: const Icon(
                  Icons.clear_outlined,
                  size: 30,
                ),
                onPressed: () {}),
          ],
        ),
      ],
      title: Text(
        "ASSESSMENT",
        style: TextStyle(
          fontSize: 20,
          color: IllumineColors.appBlackColor,
          fontWeight: Constants.kAppFonts.kFontWeightBold,
          fontFamily: Constants.kAppFonts.kFontFamily,
        ),
      ),
      centerTitle: false,
    );
  }
}

class AssesmentQuestionView extends StatefulWidget {
  const AssesmentQuestionView({Key? key}) : super(key: key);

  @override
  _AssesmentQuestionViewState createState() => _AssesmentQuestionViewState();
}

class _AssesmentQuestionViewState extends State<AssesmentQuestionView> {
  PageController pageController = PageController();
  late AssesmentViewModel _assesmentViewModel;
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _assesmentViewModel = Provider.of<AssesmentViewModel>(context);
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AssesmentViewModel>(builder: (context, data, child) {
      return Container(
        margin: const EdgeInsets.all(15),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _assesmentTitle(),
            _questionView(),
            _nextButton(),
          ],
        ),
      );
    });
  }

  Widget _assesmentTitle() {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 8),
      child: Text(
        "What happens when I become a StarMaker?",
        textAlign: TextAlign.left,
        style: TextStyle(
            fontSize: 18,
            color: IllumineColors.greyTextColor,
            fontFamily: Constants.kAppFonts.kFontFamily),
      ),
    );
  }

  Widget _questionView() {
    return Expanded(
      child: Container(
        child: Column(
          children: [
            SizedBox(
              child: Text(
                "Q: ${_assesmentViewModel.currentQuestion + 1} of ${_assesmentViewModel.totalQuestions}",
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontSize: 20,
                  color: IllumineColors.appBlackColor,
                  fontWeight: Constants.kAppFonts.kFontWeightBold,
                  fontFamily: Constants.kAppFonts.kFontFamily,
                ),
              ),
              height: 30,
              width: MediaQuery.of(context).size.width,
            ),
            Expanded(
              child: PageView(
                controller: pageController,
                onPageChanged: (value) {
                  _assesmentViewModel.updateCurrentQuestion(value);
                },
                children: _generateQuestionWidget(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _generateQuestionWidget() {
    List<Widget> widgetList = [];
    if (_assesmentViewModel.assessmentResponseModel.questions != null) {
      for (var questionItem
          in _assesmentViewModel.assessmentResponseModel.questions ?? []) {
        widgetList.add(_questionWidget(
            questionItem.question ?? "", questionItem.answers ?? []));
      }
    }

    return widgetList;
  }

  Widget _questionWidget(String question, List<Answers> options) {
    return ListView.builder(
        itemCount: options.length + 1,
        physics: const NeverScrollableScrollPhysics(),
        itemBuilder: (BuildContext context, int index) {
          if (index == 0) {
            return _questionTitleTile(question);
          } else {
            return _optionTile(options[index - 1], index - 1);
          }
        });
  }

  ListTile _questionTitleTile(String questionText) {
    return ListTile(
      title: Padding(
        padding: const EdgeInsets.only(top: 10, bottom: 10),
        child: Text(
          questionText,
          textAlign: TextAlign.start,
          style: TextStyle(
            fontSize: 20,
            color: IllumineColors.appBlackColor,
            fontWeight: Constants.kAppFonts.kFontWeightMedium,
            fontFamily: Constants.kAppFonts.kFontFamily,
          ),
        ),
      ),
    );
  }

  Widget _optionTile(Answers optionData, int index) {
    final bool isSelected = _assesmentViewModel
        .optionSelectionStatus[_assesmentViewModel.currentQuestion][index];
    return Container(
      margin: const EdgeInsets.fromLTRB(0, 10, 0, 10),
      padding: const EdgeInsets.only(top: 12, bottom: 12),
      decoration: BoxDecoration(
          color: isSelected
              ? IllumineColors.yellowColor
              : IllumineColors.lightGray,
          borderRadius: BorderRadius.circular(12.0)),
      child: ListTile(
        onTap: () {
          _assesmentViewModel.updateOptionsSelection(
              optionNumber: index, optionStatus: isSelected);
        },
        title: Text(optionData.option ?? "",
            textAlign: TextAlign.start,
            style: TextStyle(
              fontSize: 20,
              color: IllumineColors.appBlackColor,
              fontWeight: Constants.kAppFonts.kFontWeightRegular,
              fontFamily: Constants.kAppFonts.kFontFamily,
            )),
        leading: Icon(
          isSelected ? Icons.radio_button_checked : Icons.radio_button_off,
          color: Colors.black,
        ),
        minLeadingWidth: 25,
      ),
    );
  }

  Widget _nextButton() {
    return SizedBox(
      width: MediaQuery.of(context).size.width - 20,
      height: 50,
      child: Row(
        children: [
          Container(
            decoration: BoxDecoration(
                color: IllumineColors.lightPink,
                borderRadius: BorderRadius.circular(20)),
            width: 50,
            height: 50,
            child: IconButton(
              icon: const Icon(
                Icons.arrow_back_ios_new,
                color: IllumineColors.darkPink,
              ),
              onPressed: () {
                _assesmentViewModel.currentQuestion == 0
                    ? pageController
                        .jumpToPage(_assesmentViewModel.totalQuestions - 1)
                    : pageController
                        .jumpToPage(_assesmentViewModel.currentQuestion - 1);
              },
            ),
          ),
          Expanded(child: Container()),
          Container(
            width: 100,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: IllumineColors.darkPink,
            ),
            child: TextButton(
              onPressed: () {
                print(
                    "b current Question ${_assesmentViewModel.currentQuestion}");
                print("total Question ${_assesmentViewModel.totalQuestions}");
                _assesmentViewModel.currentQuestion ==
                        _assesmentViewModel.totalQuestions - 1
                    ? pageController.jumpToPage(0)
                    : pageController
                        .jumpToPage(_assesmentViewModel.currentQuestion + 1);
                print(
                    "a current Question ${_assesmentViewModel.currentQuestion}");
              },
              child: Text(
                "Next",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: Constants.kAppFonts.kFontWeightMedium,
                  fontFamily: Constants.kAppFonts.kFontFamily,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
