import 'package:flutter/material.dart';
import 'package:illumine/mvvm/view_models/login_module/registration_view_model.dart';
import 'package:illumine/src/core/value/Constants.dart';
import 'package:illumine/utility/validator.dart';
import 'package:provider/provider.dart';

import '../../../src/core/value/colors.dart';
import '../../../src/core/value/strings.dart';
import '../../../src/core/widget/primary_button.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  String? _email, _password;
  bool dataValid = false;
  bool _obscureText = true;

  static const double _defaultBorderRadius = 24.0;
  static const Color _defaultTextColor = Colors.black;
  static const Color _defaultHintColor = Color(0xFFA8A8A8);
  static const Color _defaultFillColor = Color(0xFFF6F6F6);

  late RegistrationViewModel _registerViewModel;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    _registerViewModel = Provider.of<RegistrationViewModel>(context);
    return _registerUI(context);
  }

  Scaffold _registerUI(BuildContext context) {
    return Scaffold(
      appBar: customAppBarWithTitle("Registration"),

      // AppBar(
      //   elevation: 0,
      //   backgroundColor: Colors.white,
      //   foregroundColor: Colors.black,
      //   title: const Text(""),
      // ),
      key: _scaffoldKey,
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Container(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 20.0, vertical: 16.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    _registerForm(context), // Login Form
                    SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _registerForm(BuildContext context) {
    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Colors.white,
            boxShadow: const [
              BoxShadow(
                  color: IllumineColors.loginBorderColor, spreadRadius: 1),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 14),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _getRegisterFormTitle(),
                  _getFirstNameTextField(context),
                  _getLastNameTextField(context),
                  _getEmailTextField(context),
                  _getPasswordTextField(context),
                  _getAccessCodeTextField(context),
                  _getRegisterButton(context),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Padding _getRegisterFormTitle() {
    return Padding(
      padding: Constants.kCommon.kVerticalInsetsMedium,
      child: Text(
        Strings.registerScreenTitle,
        textAlign: TextAlign.start,
        style: TextStyle(
          fontSize: Constants.kAppFonts.kFontSizeMedium,
          color: IllumineColors.textColorPrimary,
          fontWeight: Constants.kAppFonts.kFontWeightMedium,
          fontFamily: Constants.kAppFonts.kFontFamily,
        ),
      ),
    );
  }

  Padding _getPasswordTextField(BuildContext context) {
    return Padding(
      padding: Constants.kCommon.kVerticalInsetsSmall,
      child: Stack(
        children: [
          TextFormField(
            textAlign: TextAlign.start,
            keyboardType: TextInputType.text,
            obscureText: _obscureText,
            textInputAction: TextInputAction.done,
            style: TextStyle(
                color: _defaultTextColor,
                fontWeight: Constants.kAppFonts.kFontWeightRegular,
                fontSize: Constants.kAppFonts.kFontSizeSmall,
                fontFamily: Constants.kAppFonts.kFontFamily),
            scrollPadding: const EdgeInsets.only(bottom: 32.0),
            controller: _registerViewModel.passwordTextFieldController,
            autovalidateMode: AutovalidateMode.disabled,
            validator: validatePassword,
            onChanged: (password) => _password = password,
            onSaved: (password) => _password = password,
            onFieldSubmitted: (_) => FocusScope.of(context).unfocus(),
            decoration: InputDecoration(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 26, vertical: 26),
              labelText: Strings.registerScreenPasswordInputHint,
              labelStyle: TextStyle(
                  height: 6,
                  color: _defaultHintColor,
                  fontSize: Constants.kAppFonts.kFontSizeSmall),
              filled: true,
              fillColor: _defaultFillColor,
              border: OutlineInputBorder(
                borderSide: BorderSide.none,
                borderRadius: BorderRadius.circular(_defaultBorderRadius),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 22.0, top: 12),
            child: Align(
              alignment: Alignment.centerRight,
              child: IconButton(
                icon: Icon(
                    _obscureText ? Icons.visibility : Icons.visibility_off),
                onPressed: () {
                  setState(() {
                    _obscureText = !_obscureText;
                  });
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Padding _getEmailTextField(BuildContext context) {
    return Padding(
      padding: Constants.kCommon.kVerticalInsetsSmall,
      child: TextFormField(
        textAlign: TextAlign.start,
        textInputAction: TextInputAction.next,
        style: TextStyle(
            color: _defaultTextColor,
            fontWeight: Constants.kAppFonts.kFontWeightRegular,
            fontSize: Constants.kAppFonts.kFontSizeSmall,
            fontFamily: Constants.kAppFonts.kFontFamily),
        scrollPadding: const EdgeInsets.only(bottom: 32.0),
        controller: _registerViewModel.emailTextFieldController,
        autovalidateMode: AutovalidateMode.disabled,
        keyboardType: TextInputType.emailAddress,
        validator: validateEmail,
        obscureText: false,
        onChanged: (email) => _email = email,
        onSaved: (email) => _email = email,
        onFieldSubmitted: (_) => FocusScope.of(context).nextFocus(),
        decoration: InputDecoration(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 26, vertical: 26),
          labelText: Strings.registerScreenUsernameInputHint,
          labelStyle: TextStyle(
              height: 6,
              color: _defaultHintColor,
              fontSize: Constants.kAppFonts.kFontSizeSmall),
          filled: true,
          fillColor: _defaultFillColor,
          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.circular(_defaultBorderRadius),
          ),
        ),
      ),
    );
  }

  Padding _getFirstNameTextField(BuildContext context) {
    return Padding(
      padding: Constants.kCommon.kVerticalInsetsSmall,
      child: TextFormField(
        textAlign: TextAlign.start,
        textInputAction: TextInputAction.next,
        style: TextStyle(
            color: _defaultTextColor,
            fontWeight: Constants.kAppFonts.kFontWeightRegular,
            fontSize: Constants.kAppFonts.kFontSizeSmall,
            fontFamily: Constants.kAppFonts.kFontFamily),
        scrollPadding: const EdgeInsets.only(bottom: 32.0),
        controller: _registerViewModel.firstNameTextFieldController,
        autovalidateMode: AutovalidateMode.disabled,
        keyboardType: TextInputType.text,
        validator: validateNames,
        obscureText: false,
        onChanged: (email) => _email = email,
        onSaved: (email) => _email = email,
        onFieldSubmitted: (_) => FocusScope.of(context).nextFocus(),
        decoration: InputDecoration(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 26, vertical: 26),
          labelText: Strings.registerScreenFirstNameInputHint,
          labelStyle: TextStyle(
              height: 6,
              color: _defaultHintColor,
              fontSize: Constants.kAppFonts.kFontSizeSmall),
          filled: true,
          fillColor: _defaultFillColor,
          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.circular(_defaultBorderRadius),
          ),
        ),
      ),
    );
  }

  Padding _getLastNameTextField(BuildContext context) {
    return Padding(
      padding: Constants.kCommon.kVerticalInsetsSmall,
      child: TextFormField(
        textAlign: TextAlign.start,
        textInputAction: TextInputAction.next,
        style: TextStyle(
            color: _defaultTextColor,
            fontWeight: Constants.kAppFonts.kFontWeightRegular,
            fontSize: Constants.kAppFonts.kFontSizeSmall,
            fontFamily: Constants.kAppFonts.kFontFamily),
        scrollPadding: const EdgeInsets.only(bottom: 32.0),
        controller: _registerViewModel.lastNameTextFieldController,
        autovalidateMode: AutovalidateMode.disabled,
        keyboardType: TextInputType.text,
        validator: validateNames,
        obscureText: false,
        onChanged: (email) => _email = email,
        onSaved: (email) => _email = email,
        onFieldSubmitted: (_) => FocusScope.of(context).nextFocus(),
        decoration: InputDecoration(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 26, vertical: 26),
          labelText: Strings.registerScreenLastNameInputHint,
          labelStyle: TextStyle(
              height: 6,
              color: _defaultHintColor,
              fontSize: Constants.kAppFonts.kFontSizeSmall),
          filled: true,
          fillColor: _defaultFillColor,
          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.circular(_defaultBorderRadius),
          ),
        ),
      ),
    );
  }

  Padding _getAccessCodeTextField(BuildContext context) {
    return Padding(
      padding: Constants.kCommon.kVerticalInsetsSmall,
      child: TextFormField(
        textAlign: TextAlign.start,
        textInputAction: TextInputAction.next,
        style: TextStyle(
            color: _defaultTextColor,
            fontWeight: Constants.kAppFonts.kFontWeightRegular,
            fontSize: Constants.kAppFonts.kFontSizeSmall,
            fontFamily: Constants.kAppFonts.kFontFamily),
        scrollPadding: const EdgeInsets.only(bottom: 32.0),
        controller: _registerViewModel.accessCodeTextFieldController,
        autovalidateMode: AutovalidateMode.disabled,
        keyboardType: TextInputType.text,
        validator: validateNames,
        obscureText: false,
        onChanged: (email) => _email = email,
        onSaved: (email) => _email = email,
        onFieldSubmitted: (_) => FocusScope.of(context).nextFocus(),
        decoration: InputDecoration(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 26, vertical: 26),
          labelText: Strings.registerScreenAccessCodeInputHint,
          labelStyle: TextStyle(
              height: 6,
              color: _defaultHintColor,
              fontSize: Constants.kAppFonts.kFontSizeSmall),
          filled: true,
          fillColor: _defaultFillColor,
          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.circular(_defaultBorderRadius),
          ),
        ),
      ),
    );
  }

  Padding _getRegisterButton(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 20, 0, 0),
      child: PrimaryButton(
        onPressed: () {
          _registerButtonClicked();
        },
        label: Strings.loginScreenRegistrationCTAButtonLabel,
        width: double.maxFinite,
        height: Constants.kLogin.kLoginButtonHeight,
        fontSize: Constants.kAppFonts.kFontSizeMedium,
        fontWeight: Constants.kAppFonts.kFontWeightRegular,
        backgroundColor: IllumineColors.loginRedColor,
        rightArrowColor: const Color(0xFF999999),
      ),
    );
  }

  void _registerButtonClicked() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      _registerViewModel.registerUser(
          context: context, logInWithCommonLoader: true);
    }
  }
}
