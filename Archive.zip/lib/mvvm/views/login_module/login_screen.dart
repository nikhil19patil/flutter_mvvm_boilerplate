import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:illumine/mvvm/view_models/login_module/login_view_model.dart';
import 'package:illumine/src/core/value/Constants.dart';
import 'package:illumine/src/core/value/assets.dart';
import 'package:illumine/src/core/widget/secondary_button.dart';
import 'package:illumine/src/core/widget/underlined_text_button.dart';
import 'package:illumine/utility/validator.dart';
import 'package:provider/provider.dart';

import '../../../src/core/value/colors.dart';
import '../../../src/core/value/strings.dart';
import '../../../src/core/widget/primary_button.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  String? _email, _password;
  bool dataValid = false;
  bool _obscureText = true;

  static const double _defaultBorderRadius = 24.0;
  static const Color _defaultTextColor = Colors.black;
  static const Color _defaultHintColor = Color(0xFFA8A8A8);
  static const Color _defaultFillColor = Color(0xFFF6F6F6);

  late LoginViewModel _loginViewModel;

  @override
  void initState() {
    super.initState();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _loginViewModel = Provider.of<LoginViewModel>(context);
  }

  @override
  Widget build(BuildContext context) {
    return _loginUI(context);
  }

  Scaffold _loginUI(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 20.0, vertical: 16.0),
                child: Column(
                  children: [
                    _headerWelcomeText(), // Header (Image + Welcome Text)

                    const SizedBox(height: 20),

                    _loginForm(context), // Login Form

                    const SizedBox(height: 20),

                    _registrationCTA(_loginViewModel), // Registration CTA
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Column _headerWelcomeText() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8.0),
          child: SvgPicture.asset(
            Assets.loginScreenHeaderGraphics,
            height: Constants.kLogin.kHeaderGraphicsHeight,
            width: Constants.kLogin.kHeaderGraphicsWidth,
          ),
        ),
        Text(
          Strings.loginScreenLoginWelcomeTitle,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: Constants.kAppFonts.kFontSizeLarge,
            color: IllumineColors.textColorPrimary,
            fontWeight: Constants.kAppFonts.kFontWeightBold,
            fontFamily: Constants.kAppFonts.kFontFamily,
          ),
        ),
      ],
    );
  }

  Widget _loginForm(BuildContext context) {
    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Colors.white,
            boxShadow: const [
              BoxShadow(
                  color: IllumineColors.loginBorderColor, spreadRadius: 1),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 14),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _getLoginFormTitle(),
                  _getEmailTextField(context),
                  _getPasswordTextField(context),
                  _getLoginButton(),
                  _getForgotPassword(_loginViewModel),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _getORText(),
                      _getGoogleLoginButton(),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Padding _getLoginFormTitle() {
    return Padding(
      padding: Constants.kCommon.kVerticalInsetsMedium,
      child: Text(
        Strings.loginScreenLoginFormTitle,
        textAlign: TextAlign.start,
        style: TextStyle(
          fontSize: Constants.kAppFonts.kFontSizeMedium,
          color: IllumineColors.textColorPrimary,
          fontWeight: Constants.kAppFonts.kFontWeightMedium,
          fontFamily: Constants.kAppFonts.kFontFamily,
        ),
      ),
    );
  }

  Padding _getORText() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Text(
        Strings.loginScreeForeignLoginsSectionTitle,
        style: TextStyle(
          fontSize: Constants.kAppFonts.kFontSizeSmall,
          color: IllumineColors.textColorPrimary,
          fontWeight: Constants.kAppFonts.kFontWeightRegular,
          fontFamily: Constants.kAppFonts.kFontFamily,
        ),
      ),
    );
  }

  Padding _getGoogleLoginButton() {
    return Padding(
      padding: Constants.kCommon.kVerticalInsetsSmall,
      child: SecondaryButton(
        onPressed: () {
          // controller.isLoading
          //     ? null
          //     : controller.loginWithGoogle,
        },
        label: Strings.loginScreeForeignLoginsSectionGoogleButtonLabel,
        leading: SvgPicture.asset(Assets.loginScreenGoogleLogoSmall,
            height: 24.0, width: 24.0),
        fontSize: Constants.kAppFonts.kFontSizeMedium,
        fontWeight: Constants.kAppFonts.kFontWeightMedium,
      ),
    );
  }

  UnderlinedTextButton _getForgotPassword(LoginViewModel loginViewModel) {
    return UnderlinedTextButton(
        onPressed: () {
          loginViewModel.onForgotPasswordRequested(context);
        },
        label: Strings.loginScreenForgotPasswordButtonLabel,
        fontSize: Constants.kAppFonts.kFontSizeExtraSmall,
        fontWeight: Constants.kAppFonts.kFontWeightLight);
  }

  Padding _getLoginButton() {
    return Padding(
      padding: EdgeInsets.only(top: Constants.kCommon.kVerticalInsetsSmall.top),
      child: PrimaryButton(
        rightArrowColor: const Color(0xFF999999),
        onPressed: () {
          _loginButtonClicked();
        },
        label: Strings.loginScreenFormSubmissionButtonLabel,
        width: double.maxFinite,
        height: Constants.kLogin.kLoginButtonHeight,
        fontSize: Constants.kAppFonts.kFontSizeMedium,
        fontWeight: Constants.kAppFonts.kFontWeightRegular,
        backgroundColor: IllumineColors.loginButtonColor,
      ),
    );
  }

  void _loginButtonClicked() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      _loginViewModel.loginUser(context: context, logInWithCommonLoader: true);
    }
  }

  Padding _getPasswordTextField(BuildContext context) {
    return Padding(
      padding: Constants.kCommon.kVerticalInsetsSmall,
      child: Stack(
        children: [
          TextFormField(
            textAlign: TextAlign.start,
            keyboardType: TextInputType.text,
            obscureText: _obscureText,
            textInputAction: TextInputAction.done,
            style: TextStyle(
                color: _defaultTextColor,
                fontWeight: Constants.kAppFonts.kFontWeightRegular,
                fontSize: Constants.kAppFonts.kFontSizeSmall,
                fontFamily: Constants.kAppFonts.kFontFamily),
            scrollPadding: const EdgeInsets.only(bottom: 32.0),
            controller: _loginViewModel.passwordTextFieldController,
            autovalidateMode: AutovalidateMode.disabled,
            validator: validatePassword,
            onChanged: (password) => _password = password,
            onSaved: (password) => _password = password,
            onFieldSubmitted: (_) => FocusScope.of(context).unfocus(),
            decoration: InputDecoration(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 26, vertical: 26),
              hintText: Strings.loginScreenPasswordInputHint,
              hintStyle: TextStyle(
                  color: _defaultHintColor,
                  fontSize: Constants.kAppFonts.kFontSizeSmall),
              filled: true,
              fillColor: _defaultFillColor,
              border: OutlineInputBorder(
                borderSide: BorderSide.none,
                borderRadius: BorderRadius.circular(_defaultBorderRadius),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 22.0, top: 12),
            child: Align(
              alignment: Alignment.centerRight,
              child: IconButton(
                icon: Icon(
                    _obscureText ? Icons.visibility : Icons.visibility_off),
                onPressed: () {
                  setState(() {
                    _obscureText = !_obscureText;
                  });
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Padding _getEmailTextField(BuildContext context) {
    return Padding(
      padding: Constants.kCommon.kVerticalInsetsSmall,
      child: TextFormField(
        textAlign: TextAlign.start,
        textInputAction: TextInputAction.next,
        style: TextStyle(
            color: _defaultTextColor,
            fontWeight: Constants.kAppFonts.kFontWeightRegular,
            fontSize: Constants.kAppFonts.kFontSizeSmall,
            fontFamily: Constants.kAppFonts.kFontFamily),
        scrollPadding: const EdgeInsets.only(bottom: 32.0),
        controller: _loginViewModel.emailTextFieldController,
        autovalidateMode: AutovalidateMode.disabled,
        keyboardType: TextInputType.emailAddress,
        validator: validateEmail,
        obscureText: false,
        onChanged: (email) => _email = email,
        onSaved: (email) => _email = email,
        onFieldSubmitted: (_) => FocusScope.of(context).nextFocus(),
        decoration: InputDecoration(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 26, vertical: 26),
          hintText: Strings.loginScreenUsernameInputHint,
          hintStyle: TextStyle(
              color: _defaultHintColor,
              fontSize: Constants.kAppFonts.kFontSizeSmall),
          filled: true,
          fillColor: _defaultFillColor,
          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.circular(_defaultBorderRadius),
          ),
        ),
      ),
    );
  }

  Widget _registrationCTA(LoginViewModel loginViewModel) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: IllumineColors.loginGreyColor,
        // boxShadow: [
        //   BoxShadow(color: Colors.green, spreadRadius: 3),
        // ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              Strings.loginScreenRegistrationCTATitle,
              style: TextStyle(
                  fontFamily: Constants.kAppFonts.kFontFamily,
                  fontSize: Constants.kAppFonts.kFontSizeMedium,
                  color: IllumineColors.textColorPrimary,
                  fontWeight: Constants.kAppFonts.kFontWeightMedium),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 20, 0, 0),
              child: PrimaryButton(
                onPressed: () {
                  loginViewModel.onRegistrationRequested(context);
                },
                label: Strings.loginScreenRegistrationCTAButtonLabel,
                width: double.maxFinite,
                height: Constants.kLogin.kLoginButtonHeight,
                fontSize: Constants.kAppFonts.kFontSizeMedium,
                fontWeight: Constants.kAppFonts.kFontWeightRegular,
                backgroundColor: IllumineColors.loginRedColor,
                rightArrowColor: const Color(0xFF999999),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
