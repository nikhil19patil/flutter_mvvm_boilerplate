import 'package:flutter/material.dart';
import 'package:illumine/mvvm/helpers/singleton_constant.dart';
import 'package:illumine/mvvm/models/login_module/login_response_model.dart';
import 'package:illumine/mvvm/views/dashboard_module/dashboard_screen.dart';
import 'package:illumine/mvvm/views/login_module/login_screen.dart';
import 'package:illumine/providers/user_provider.dart';
import 'package:illumine/utility/shared_preference.dart';
import 'package:provider/provider.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool isLoading = true;
  @override
  Widget build(BuildContext context) {
    Future<LoginResponseModel>? getUserData() => SharedPref().getUser();
    return _buildFutureBuilder(getUserData);
  }

  Scaffold _splashScaffold() {
    return Scaffold(
      body: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: const <Widget>[
            Padding(
              padding: EdgeInsets.only(bottom: 8.0),
              child: Icon(
                Icons.cable_rounded,
                size: 40,
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: const SafeArea(
        child: Text(
          "Loading...",
          textAlign: TextAlign.center,
        ),
      ),
    );
  }

  FutureBuilder<LoginResponseModel> _buildFutureBuilder(
      Future<LoginResponseModel>? getUserData()) {
    return FutureBuilder(
        future: getUserData(),
        builder: (context, snapshot) {
          switch (snapshot.connectionState) {
            case ConnectionState.none:
            case ConnectionState.waiting:
              return _splashScaffold();
            default:
              if (snapshot.hasError) {
                debugPrint("snapshot.hasError");
                return LoginScreen();
              } else if (snapshot.data?.user == null) {
                debugPrint("snapshot.data?.id == null");
                return LoginScreen();
              } else {
                debugPrint("has data");
                Provider.of<UserProvider>(context).setUser(snapshot.data?.user);
                if (snapshot.data != null) {
                  SingletonConstants().setUser(snapshot.data!);
                }
                return DashboardScreen();
              }
          }
        });
  }
}
