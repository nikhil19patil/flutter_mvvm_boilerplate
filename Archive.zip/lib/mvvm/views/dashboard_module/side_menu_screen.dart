import 'package:flutter/material.dart';
import 'package:illumine/src/core/value/Constants.dart';
import 'package:illumine/src/core/value/colors.dart';
import 'package:illumine/utility/route_generator.dart';
import 'package:illumine/utility/shared_preference.dart';

class NavDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            child: Text(
              'User Info',
              style: TextStyle(color: Colors.black, fontSize: 25),
            ),
            decoration: BoxDecoration(
              color: Colors.white,
              // image: DecorationImage(
              //     fit: BoxFit.fill,
              //     image: AssetImage('assets/images/cover.jpg'),
              // ),
            ),
          ),
          ListTile(
            leading: Icon(Icons.input),
            title: Text(
              'StarMaker Program',
              style: _buildTextStyle(),
            ),
            onTap: () => {},
          ),
          ListTile(
            leading: Icon(Icons.verified_user),
            title: Text(
              'Join New Program',
              style: _buildTextStyle(),
            ),
            onTap: () => {
              //RouteManger.navigateTo(Pages.temp, type: NavigationType.add),
            },
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text(
              'My Account',
              style: _buildTextStyle(),
            ),
            onTap: () => {
              //RouteManger.navigateTo(Pages.temp, type: NavigationType.add),
            },
          ),
          ListTile(
            leading: Icon(Icons.border_color),
            title: Text(
              'App Walkthrough',
              style: _buildTextStyle(),
            ),
            onTap: () => {
              //RouteManger.navigateTo(Pages.temp, type: NavigationType.add),
            },
          ),
          ListTile(
            leading: Icon(Icons.border_color),
            title: Text(
              'FAQs',
              style: _buildTextStyle(),
            ),
            onTap: () => {
              //RouteManger.navigateTo(Pages.temp, type: NavigationType.add),
            },
          ),
          ListTile(
            leading: Icon(Icons.exit_to_app),
            title: Text(
              'Logout',
              style: _buildTextStyle(),
            ),
            onTap: () {
              showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text('Confirm Sign out'),
                      content: Text('Are  sure to sign out from app now?'),
                      actions: [
                        TextButton(
                          onPressed: () {},
                          child: Text('Cancel'),
                        ),
                        TextButton(
                          onPressed: () async {
                            SharedPref().clearUserDataFromSharedPref();
                            Navigator.of(context)
                                .popAndPushNamed(RouteConstants.kLoginScreen);
                          },
                          child: Text('Yes'),
                        )
                      ],
                    );
                  });
            },
          ),
        ],
      ),
    );
  }

  TextStyle _buildTextStyle() {
    return TextStyle(
      fontSize: 20,
      color: IllumineColors.appBlackColor,
      fontWeight: FontWeight.normal,
      fontFamily: Constants.kAppFonts.kFontFamily,
    );
  }
}
