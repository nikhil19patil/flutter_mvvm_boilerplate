import 'package:cached_network_image/cached_network_image.dart';
import 'package:card_swiper/card_swiper.dart';
import 'package:flutter/material.dart';
import 'package:illumine/mvvm/models/dashboard/dashboard_response_model.dart';
import 'package:illumine/mvvm/view_models/dashboard/dashbord_view_model.dart';
import 'package:illumine/mvvm/views/dashboard_module/side_menu_screen.dart';
import 'package:illumine/providers/user_provider.dart';
import 'package:illumine/src/core/config/size_config.dart';
import 'package:illumine/src/core/value/Constants.dart';
import 'package:illumine/src/core/value/colors.dart';
import 'package:illumine/utility/route_generator.dart';
import 'package:provider/provider.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int counter = 5;

  BorderRadiusGeometry radius_slidingUpPanel = BorderRadius.only(
    topLeft: Radius.circular(16.0),
    topRight: Radius.circular(16.0),
  );

  ScrollController sc = ScrollController();

  final myImageAndCaption = [
    ["assets/icons/icon1.svg", "Coaching\nSessions"],
    ["assets/icons/icon1.svg", "Self \n Learning"],
    ["assets/icons/icon1.svg", "Flashpoint \n Finder"],
    ["assets/icons/icon1.svg", "Growth \n Tracker"],
    ["assets/icons/icon1.svg", "Tests & \n Surveys"],
  ];

  final arrCardColors = [
    Color(0xFFFFAA00),
    Color(0xFFFBD30D),
    Color(0xFFF9D982),
    Color(0xFF7EF6FF),
    Color(0xFFFFAA00),
    Color(0xFFFBD30D),
    Color(0xFFF9D982),
    Color(0xFF7EF6FF),
    Color(0xFFFFAA00),
    Color(0xFFFBD30D),
    Color(0xFFF9D982),
    Color(0xFF7EF6FF),
    Color(0xFFFFAA00),
    Color(0xFFFBD30D),
    Color(0xFFF9D982),
    Color(0xFF7EF6FF),
    Color(0xFFFFAA00),
    Color(0xFFFBD30D),
    Color(0xFFF9D982),
    Color(0xFF7EF6FF),
    Color(0xFFFFAA00),
    Color(0xFFFBD30D),
    Color(0xFFF9D982),
    Color(0xFF7EF6FF),
    Color(0xFFFFAA00),
    Color(0xFFFBD30D),
    Color(0xFFF9D982),
    Color(0xFF7EF6FF),
  ];

  late DashboardViewModel _dashboardViewModel;
  //late Future<DashboardResponseModel> _response;
  late String _username;

  @override
  void initState() {
    super.initState();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _dashboardViewModel = Provider.of<DashboardViewModel>(context);
    //_response = _dashboardViewModel.getDataForDashboard(context: context);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Scaffold(
        drawer: NavDrawer(),
        appBar: _customAppBar(),
        body: FutureBuilder(
          future: _dashboardViewModel.getDataForDashboard(
              context: context), //_response,
          builder: (context, AsyncSnapshot<DashboardResponseModel> snapshot) {
            switch (snapshot.connectionState) {
              case ConnectionState.none:
              case ConnectionState.waiting:
                return const Center();
              default:
                final cardList = snapshot.data?.card;
                return SingleChildScrollView(
                  controller: sc,
                  child: Container(
                    color: Colors.white,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _getUserName(),
                        _messageForUser(),
                        _cardViewContainer(),
                        _textBeforBottomOption(),
                        _bottomOptions(),
                      ],
                    ),
                  ),
                );
            }
          },
        ),
      ),
    );
  }

  SizedBox _bottomOptions() {
    return SizedBox(
      height: 300,
      child: Container(
        color: Colors.white,
        child: Padding(
            padding: EdgeInsets.fromLTRB(25, 10, 25, 20),
            child: _scrollingGrid(sc, myImageAndCaption)),
      ),
    );
  }

  Row _textBeforBottomOption() {
    return Row(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(32, 10, 8, 0),
          child: Container(
            height: 30,
            child: Text(
              "Your Growth Toolbox",
              style: TextStyle(
                fontSize: 18,
                color: IllumineColors.appBlackColor,
                fontWeight: Constants.kAppFonts.kFontWeightBold,
                fontFamily: Constants.kAppFonts.kFontFamily,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Container _cardViewContainer() {
    late List<AppCard>? cards = _dashboardViewModel.dashboardResponseModel.card;
    debugPrint(
        "SizeConfig.screenHeight * 0.6 = ${SizeConfig.screenHeight * 0.6}");
    return Container(
      height: 560, //SizeConfig.screenHeight * 0.6,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(2, 0, 2, 0),
        child: Container(
          color: Colors.white,
          child: Swiper(
            itemCount: cards != null ? cards.length : 0,
            itemBuilder: (BuildContext context, int index) {
              return _cardView(index, cards!);
            },
            viewportFraction: 0.90,
            loop: false,
            control: SwiperControl(
              size: 0,
            ),
            pagination: SwiperPagination(
              builder: DotSwiperPaginationBuilder(
                  color: Color(0xFF93A2A4),
                  activeColor: Colors.black //Color(0xFFF9D982),
                  ),
            ),
          ),
        ),
      ),
    );
  }

  Row _messageForUser() {
    return Row(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(32, 0, 8, 8),
          child: Container(
            height: 30,
            child: Text(
              "3 alerts to get you started",
              style: TextStyle(
                fontSize: 18,
                color: IllumineColors.appBlackColor,
                fontWeight: Constants.kAppFonts.kFontWeightBold,
                fontFamily: Constants.kAppFonts.kFontFamily,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Row _getUserName() {
    return Row(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(32, 16, 8, 0),
          child: Container(
            height: 30,
            child: Text(
              "Hi ${context.watch<UserProvider>().user.fullname}!",
              style: TextStyle(
                fontSize: 18,
                color: IllumineColors.dashboardUserNameColor,
                fontWeight: Constants.kAppFonts.kFontWeightRegular,
                fontFamily: Constants.kAppFonts.kFontFamily,
              ),
            ),
          ),
        ),
      ],
    );
  }

  AppBar _customAppBar() {
    return AppBar(
      elevation: 0,
      backgroundColor: Colors.white,
      foregroundColor: Colors.black,
      actions: [
        // IconButton(
        //   icon: Icon(Icons.notifications, color: Colors.black),
        //   onPressed: () {},
        // ),
        Stack(
          children: <Widget>[
            new IconButton(
                icon: Icon(
                  Icons.notifications,
                  size: 30,
                ),
                onPressed: () {
                  //RouteManger.navigateTo(Pages.temp, type: NavigationType.add);
                }),
            counter != 0
                ? new Positioned(
                    right: 11,
                    top: 11,
                    child: new Container(
                      padding: EdgeInsets.all(2),
                      decoration: new BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      constraints: BoxConstraints(
                        minWidth: 14,
                        minHeight: 14,
                      ),
                      child: Text(
                        '$counter',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  )
                : new Container()
          ],
        ),
      ],
      title: Text(
        "StarMaker Program",
        style: TextStyle(
          fontSize: 20,
          color: IllumineColors.appBlackColor,
          fontWeight: Constants.kAppFonts.kFontWeightBold,
          fontFamily: Constants.kAppFonts.kFontFamily,
        ),
      ),
      centerTitle: false,
    );
  }

  Widget _cardView(int index, List<AppCard> cards) {
    var card = cards[index];
    var cardColor = arrCardColors[index];

    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 2, 10, 40),
      child: Container(
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.all(const Radius.circular(20.0)),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
          child: Column(
            children: [
              cardViewPart1(card),
              cardViewPart2(card),
              cardViewPart3(card),
            ],
          ),
        ),
      ),
    );
  }

  Widget cardViewPart3(AppCard card) {
    return Expanded(
      flex: 1,
      child: Container(
        //color: Colors.yellowAccent,
        child: Center(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: 16,
                ),
                Text(
                  card.description ??
                      "NA", //"LEARNING HOUR 2: \nWhat happens when I \nbecome a StarMaker?",
                  textAlign: TextAlign.start,
                  style: TextStyle(
                    fontSize: 16,
                    color: IllumineColors.appBlackColor,
                    fontWeight: Constants.kAppFonts.kFontWeightBold,
                    fontFamily: Constants.kAppFonts.kFontFamily,
                  ),
                ),
                SizedBox(
                  height: 16,
                ),
                InkWell(
                  onTap: () {
                    print("tapped");
                  },
                  child: Container(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 24),
                          child: Row(
                            children: [
                              Expanded(
                                flex: 1,
                                child: Text(
                                  card.cta?.first.title ??
                                      "NA", //"Connect to LIVE CLASS \n17 Dec - 04m:13s",
                                  textAlign: TextAlign.start,
                                  overflow: TextOverflow.fade,
                                  maxLines: 2,
                                  //softWrap: false,
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: IllumineColors.appWhiteColor,
                                    fontWeight:
                                        Constants.kAppFonts.kFontWeightMedium,
                                    fontFamily: Constants.kAppFonts.kFontFamily,
                                  ),
                                ),
                              ),
                              //Spacer(),
                              Icon(
                                Icons.arrow_forward_ios,
                                color: Colors.white,
                                size: 16,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    width: double.maxFinite, //SizeConfig.screenWidth * 0.6,
                    height: 64.0,
                    decoration: BoxDecoration(
                      color: Color(0xFF04192A),
                      borderRadius:
                          BorderRadius.all(const Radius.circular(30.0)),
                    ),
                  ),
                ),
                SizedBox(
                  height: 16,
                ),
                Text(
                  card.remark ?? "NA", //"Earn upto 10 certification points!",
                  style: TextStyle(
                    fontSize: 14,
                    color: IllumineColors.appBlackColor,
                    fontWeight: Constants.kAppFonts.kFontWeightLight,
                    fontFamily: Constants.kAppFonts.kFontFamily,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget cardViewPart2(AppCard card) {
    return Expanded(
      flex: 1,
      child: Container(
        //color: Colors.lightGreenAccent,
        child: Padding(
          padding: EdgeInsets.all(4),
          child: Center(
            child: CachedNetworkImage(
              placeholder: (context, url) => const CircularProgressIndicator(),
              imageUrl: card.icon ?? "",
            ),
            //
            // SvgPicture.asset(
            //   "assets/icons/Group4500.svg",
            //   fit: BoxFit.fill,
            // ),
          ),
        ),
      ),
    );
  }

  Padding cardViewPart1(AppCard card) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 10, 10),
      child: Row(
        children: [
          Container(
            height: 40,
            width: 40,
            color: Color(0xFFFBD30D),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.only(bottom: 0, top: 0),
                child: CachedNetworkImage(
                  placeholder: (context, url) =>
                      const CircularProgressIndicator(),
                  imageUrl: card.title?.src ?? "",
                ),

                // SvgPicture.asset(
                //   "assets/icons/icon1.svg",
                //   fit: BoxFit.fill,
                // ),
              ),
            ),
          ),
          SizedBox(
            width: 16,
          ),
          Column(
            children: [
              Text(
                "${(card.title?.title ?? "") + "\n" + (card.title?.description ?? "")}",
                textAlign: TextAlign.start,
                style: TextStyle(
                  fontSize: 13,
                  color: IllumineColors.appBlackColor,
                  fontWeight: Constants.kAppFonts.kFontWeightMedium,
                  fontFamily: Constants.kAppFonts.kFontFamily,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _scrollingGrid(
      ScrollController sc, List<List<String>> myImageAndCaption) {
    late List<Service>? services =
        _dashboardViewModel.dashboardResponseModel.service ?? [];

    return GridView.count(
      mainAxisSpacing: 8,
      crossAxisSpacing: 8,
      controller: sc,
      crossAxisCount: 3,
      children: [
        ...services.map(
          (service) => _gridCell(service),
        ),
      ],
    );
  }

  Widget _gridCell(Service service) {
    return InkWell(
      onTap: () => {
        Navigator.of(context).pushNamed(RouteConstants.kAssessmentScreen)
        //RouteManger.navigateTo(Pages.temp, type: NavigationType.add),
      },
      child: Container(
        decoration: new BoxDecoration(
          color: IllumineColors.appLightGreyColor, //F2F2F2
          borderRadius: BorderRadius.circular(10),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(4, 8, 4, 4),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.only(
                        bottom: 4.0,
                        top: 4,
                      ),
                      child: Container(
                        height: 60,
                        width: 30,
                        child: CachedNetworkImage(
                          placeholder: (context, url) =>
                              const CircularProgressIndicator(),
                          imageUrl: service.icon ?? "",
                        ),
                      ),

                      // SvgPicture.asset(
                      //   i.first,
                      //   fit: BoxFit.fitWidth,
                      //   height: 60,
                      //   width: 30,
                      // ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                      bottom: 2.0,
                    ),
                    child: Container(
                      alignment: Alignment.bottomCenter,
                      child: Text(
                        service.title ?? "",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 14,
                          color: IllumineColors.appBlackColor,
                          fontWeight: Constants.kAppFonts.kFontWeightRegular,
                          fontFamily: Constants.kAppFonts.kFontFamily,
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/*
       {
            "_id": "61657cef6d5d400030224e4f",
            "title": {
                "title": "LIVE CLASS ALERT!",
                "description": "for 'Starmaker Madurai'",
                "src": "https://picsum.photos/38"
            },
            "description": "LEARNING HOUR 2: What happens when I become a StarMaker?",
            "icon": "https://picsum.photos/330/182",
            "expiredOn": "2021-12-26T07:13:57.655Z",
            "sessionStartTime": "2021-12-26T07:13:57.655Z",
            "cta": [
                {
                    "title": "Connect to LIVE CLASS 17 Dec",
                    "action": {
                        "url": "deep link to component"
                    }
                }
            ],
            "remark": "Earn upto 10 certification points!",
            "status": "unread"
        },


     {
            "title": "Track Growth",
            "icon": "https://picsum.photos/200",
            "color": "#00FF00",
            "text": "Going Good"
        }

 */
