import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:illumine/mvvm/Helpers/api_helper.dart';
import 'package:illumine/mvvm/models/Common/response_data_model.dart';
import 'package:illumine/mvvm/models/dashboard/dashboard_request_model.dart';
import 'package:illumine/mvvm/models/dashboard/dashboard_response_model.dart';
import 'package:illumine/mvvm/services/dashboard_services.dart';

class DashboardViewModel extends ChangeNotifier {
  ApiStatus loadingStatus = ApiStatus.idle;

  late DashboardResponseModel dashboardResponseModel;

  Future<DashboardResponseModel> getDataForDashboard({
    required BuildContext context,
    bool isUseCommonLoader = false,
  }) async {
    if (!isUseCommonLoader) {
      loadingStatus = ApiStatus.started;
    }

    DasboardRequestModel model =
        DasboardRequestModel(studentId: "61657cef6d5d400030224e4f");

    ResponseData responseData = await DashboardServices().getCardsAndServices(
        context: context, model: model, isUseCommonLoader: true);

    if (responseData.ok) {
      //TODO: Push to next screen
      loadingStatus = ApiStatus.completed;

      if (responseData.rawResponseBody != null) {
        Map json = jsonDecode(responseData.rawResponseBody!);
        DashboardResponseModel model = DashboardResponseModel.fromJson(json);
        dashboardResponseModel = model;
        debugPrint("model = ${model.toJson()}");
      }
    } else {
      loadingStatus = ApiStatus.failed;
    }

    loadingStatus = ApiStatus.idle;
    return dashboardResponseModel;
  }

  void onForgotPasswordRequested(BuildContext context) {
    //Navigator.of(context).pushReplacementNamed(RouteConstants.kForgotPassword);
  }
}
