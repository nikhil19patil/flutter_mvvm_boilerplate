import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:illumine/mvvm/Helpers/alert_bar.dart';
import 'package:illumine/mvvm/Helpers/api_helper.dart';
import 'package:illumine/mvvm/Services/login_services.dart';
import 'package:illumine/mvvm/models/Common/response_data_model.dart';
import 'package:illumine/mvvm/models/registration/registration_request_model.dart';
import 'package:illumine/mvvm/models/registration/registration_response_model.dart';
import 'package:illumine/utility/route_generator.dart';

class RegistrationViewModel extends ChangeNotifier {
  ApiStatus loadingStatus = ApiStatus.idle;

  TextEditingController firstNameTextFieldController =
      // TextEditingController(text: "");
      TextEditingController(text: "Test");
  TextEditingController lastNameTextFieldController =
      // TextEditingController(text: "");
      TextEditingController(text: "Last");
  TextEditingController emailTextFieldController =
      // TextEditingController(text: "");
      TextEditingController(text: "josh_test2@gmail.com");
  TextEditingController passwordTextFieldController =
      // TextEditingController(text: "");
      TextEditingController(text: "Test@123");
  TextEditingController accessCodeTextFieldController =
      // TextEditingController(text: "");
      TextEditingController(text: "JOSH");

  void registerUser({
    required BuildContext context,
    bool logInWithCommonLoader: false,
  }) async {
    if (emailTextFieldController.text.isEmpty) {
      AlertBar.show(context,
          title: "Enter email", description: "Please enter an Email");
      return;
    }
    if (passwordTextFieldController.text.isEmpty) {
      AlertBar.show(context,
          title: "Enter password", description: "Please enter a Password");
      return;
    }
    if (firstNameTextFieldController.text.isEmpty) {
      AlertBar.show(context,
          title: "Enter first name", description: "Please enter First Name");
      return;
    }
    if (lastNameTextFieldController.text.isEmpty) {
      AlertBar.show(context,
          title: "Enter last name", description: "Please enter Last Name");
      return;
    }
    if (accessCodeTextFieldController.text.isEmpty) {
      AlertBar.show(context,
          title: "Enter access code", description: "Please enter Access Code");
      return;
    }

    if (!logInWithCommonLoader) {
      loadingStatus = ApiStatus.started;
      notifyListeners();
    }

    RegistrationRequestModel _registrationModel = RegistrationRequestModel(
        email: emailTextFieldController.text.trim(),
        password: passwordTextFieldController.text,
        fullname: firstNameTextFieldController.text +
            lastNameTextFieldController.text,
        accesscode: accessCodeTextFieldController.text);

    ResponseData responseData = await LoginService().registerUser(
        context: context,
        registrationRequestModel: _registrationModel,
        commonLoader: logInWithCommonLoader);

    if (responseData.ok) {
      //TODO: Push to next screen

      loadingStatus = ApiStatus.completed;

      if (responseData.rawResponseBody != null) {
        Map<String, dynamic> json = jsonDecode(responseData.rawResponseBody!);
        RegistrationResponse model = RegistrationResponse.fromJson(json);

        debugPrint("model fullname = ${model.user?.fullname}");

        AlertBar.show(
          context,
          title: "Done",
          description: "Registration Successful. Please login.",
          backgroundColor: Colors.green,
        );
        await Future.delayed(const Duration(seconds: 1));
        Navigator.of(context).pushReplacementNamed(RouteConstants.kLoginScreen);
      }
    } else {
      loadingStatus = ApiStatus.failed;
      AlertBar.show(
        context,
        title: "Error",
        description: responseData.message ?? "Something went wrong",
        backgroundColor: Colors.red,
      );
    }

    //notifyListeners();

    //await Future.delayed(const Duration(seconds: 3));

    loadingStatus = ApiStatus.idle;
    notifyListeners();
  }
}
