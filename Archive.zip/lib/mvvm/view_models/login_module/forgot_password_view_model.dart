import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:illumine/mvvm/Helpers/alert_bar.dart';
import 'package:illumine/mvvm/Helpers/api_helper.dart';
import 'package:illumine/mvvm/Services/login_services.dart';
import 'package:illumine/mvvm/models/Common/response_data_model.dart';
import 'package:illumine/mvvm/models/forgot_password/forgot_password_request_model.dart';
import 'package:illumine/mvvm/models/login_module/login_request_model.dart';
import 'package:illumine/mvvm/models/login_module/login_response_model.dart';
import 'package:illumine/mvvm/models/registration/registration_request_model.dart';
import 'package:illumine/mvvm/models/registration/registration_response_model.dart';
import 'package:illumine/providers/user_provider.dart';
import 'package:illumine/src/core/value/Constants.dart';
import 'package:illumine/utility/route_generator.dart';
import 'package:illumine/utility/shared_preference.dart';
import 'package:provider/provider.dart';

class ForgotPasswordViewModel extends ChangeNotifier {
  ApiStatus loadingStatus = ApiStatus.idle;

  TextEditingController emailTextFieldController =
  // TextEditingController(text: "");
  TextEditingController(text: "josh_test2@gmail.com");

  void forgotPassword({
    required BuildContext context,
    bool logInWithCommonLoader: false,
  }) async {
    if (emailTextFieldController.text.isEmpty) {
      AlertBar.show(context,
          title: "Enter email", description: "Please enter an Email");
      return;
    }

    if (!logInWithCommonLoader) {
      loadingStatus = ApiStatus.started;
      notifyListeners();
    }

    ForgotPasswordRequestModel _forgotPasswordModel = ForgotPasswordRequestModel(
        email: emailTextFieldController.text.trim());

    ResponseData responseData = await LoginService().forgotPassword(
        context: context,
        forgotPasswordRequestModel: _forgotPasswordModel,
        commonLoader: logInWithCommonLoader);

    if (responseData.ok) {
      //TODO: Push to next screen

      loadingStatus = ApiStatus.completed;

      if (responseData.rawResponseBody != null) {
        Map<String, dynamic> json = jsonDecode(responseData.rawResponseBody!);
        RegistrationResponse model = RegistrationResponse.fromJson(json);

        debugPrint("model fullname = ${model.user?.fullname}");

        AlertBar.show(
          context,
          title: "Done",
          description: "Registration Successful. Please login.",
          backgroundColor: Colors.green,
        );

        Navigator.of(context).pushReplacementNamed(RouteConstants.kLoginScreen);
      }
    } else {
      loadingStatus = ApiStatus.failed;
      AlertBar.show(
        context,
        title: "Error",
        description: responseData.message ?? "Something went wrong",
        backgroundColor: Colors.red,
      );
    }

    notifyListeners();

    await Future.delayed(const Duration(seconds: 3));

    loadingStatus = ApiStatus.idle;
    notifyListeners();
  }
}
