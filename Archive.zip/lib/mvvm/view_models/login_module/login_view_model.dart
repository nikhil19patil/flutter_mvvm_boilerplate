import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:illumine/mvvm/Helpers/alert_bar.dart';
import 'package:illumine/mvvm/Helpers/api_helper.dart';
import 'package:illumine/mvvm/Services/login_services.dart';
import 'package:illumine/mvvm/models/Common/response_data_model.dart';
import 'package:illumine/mvvm/models/login_module/login_request_model.dart';
import 'package:illumine/mvvm/models/login_module/login_response_model.dart';
import 'package:illumine/providers/user_provider.dart';
import 'package:illumine/src/core/value/Constants.dart';
import 'package:illumine/utility/route_generator.dart';
import 'package:illumine/utility/shared_preference.dart';
import 'package:provider/provider.dart';

class LoginViewModel extends ChangeNotifier {
  ApiStatus loadingStatus = ApiStatus.idle;

  TextEditingController emailTextFieldController =
      TextEditingController(text: "test@joshsoftware.com");
  TextEditingController passwordTextFieldController =
      TextEditingController(text: "Test@1234");

  void loginUser({
    required BuildContext context,
    bool logInWithCommonLoader = false,
  }) async {
    if (emailTextFieldController.text.isEmpty) {
      AlertBar.show(context,
          title: "Enter email", description: "Please enter a Email");
      return;
    }
    if (passwordTextFieldController.text.isEmpty) {
      AlertBar.show(context,
          title: "Enter password", description: "Please enter a Password");
      return;
    }

    if (!logInWithCommonLoader) {
      loadingStatus = ApiStatus.started;
      notifyListeners();
    }

    LoginRequestModel _loginModel = LoginRequestModel(
        email: emailTextFieldController.text.trim(),
        password: passwordTextFieldController.text);

    ResponseData responseData = await LoginService().loginUser(
        context: context,
        loginModel: _loginModel,
        logInWithCommonLoader: logInWithCommonLoader);

    if (responseData.ok) {
      //TODO: Push to next screen

      loadingStatus = ApiStatus.completed;

      if (responseData.rawResponseBody != null) {
        Map json = jsonDecode(responseData.rawResponseBody!);
        LoginResponseModel model = LoginResponseModel.fromJson(json);

        debugPrint("model fullname = ${model.user?.fullname}");

        Provider.of<UserProvider>(context, listen: false).setUser(model.user);

        await SharedPref()
            .save(Constants.kSharedPrefConstant.kUserModel, model.toJson());

        await SharedPref().save(Constants.kSharedPrefConstant.kAuthToken,
            model.tokens?.access?.token ?? "");

        AlertBar.show(
          context,
          title: "Done",
          description: "Login Successful Token: ${model.user?.fullname}",
          backgroundColor: Colors.green,
        );
        await Future.delayed(const Duration(seconds: 1));
        Navigator.of(context).pushReplacementNamed(RouteConstants.kDashboard);
      }
    } else {
      loadingStatus = ApiStatus.failed;
    }

    //notifyListeners();
    //await Future.delayed(const Duration(seconds: 3));

    loadingStatus = ApiStatus.idle;
    notifyListeners();
  }

  void loginWithGoogle(BuildContext context) {
    // Navigator.of(context).pushReplacementNamed(RouteConstants.kGoogleLogin);
  }

  void onForgotPasswordRequested(BuildContext context) {
    Navigator.of(context).pushNamed(RouteConstants.kForgotPassword);
  }

  void onRegistrationRequested(BuildContext context) {
    Navigator.of(context).pushNamed(RouteConstants.kRegister);
  }
}
