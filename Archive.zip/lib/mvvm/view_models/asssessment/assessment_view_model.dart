import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:illumine/mvvm/Helpers/api_helper.dart';
import 'package:illumine/mvvm/Services/assessment_services.dart';
import 'package:illumine/mvvm/models/Common/response_data_model.dart';
import 'package:illumine/mvvm/models/assessment/assessment_request_model.dart';
import 'package:illumine/mvvm/models/assessment/assessment_response_model.dart';

class AssesmentViewModel extends ChangeNotifier {
  int totalQuestions = 0;
  int currentQuestion = 0;
  ApiStatus loadingStatus = ApiStatus.idle;

  late List<List<bool>> optionSelectionStatus;
  late AssessmentResponseModel assessmentResponseModel;

  updateCurrentQuestion(int currentQuestion) {
    this.currentQuestion = currentQuestion;
    notifyListeners();
  }

  updateOptionsSelection(
      {required int optionNumber, required bool optionStatus}) {
    var currentStatus = optionSelectionStatus[currentQuestion][optionNumber];
    optionSelectionStatus[currentQuestion][optionNumber] = !currentStatus;
    notifyListeners();
  }

  Future<AssessmentResponseModel> getAssessmentData({
    required BuildContext context,
    bool logInWithCommonLoader = false,
  }) async {
    if (!logInWithCommonLoader) {
      loadingStatus = ApiStatus.started;
      // notifyListeners();
    }

    AssessmentRequestModel _assesmentRequesModel =
        AssessmentRequestModel(moduleId: "61656c34b35631eb125797eb");

    ResponseData responseData = await AssessmentService().getAssesmentData(
        context: context,
        assessmentRequestModel: _assesmentRequesModel,
        logInWithCommonLoader: logInWithCommonLoader);

    if (responseData.ok) {
      loadingStatus = ApiStatus.completed;

      if (responseData.rawResponseBody != null) {
        Map json = jsonDecode(responseData.rawResponseBody ?? "");
        AssessmentResponseModel model = AssessmentResponseModel.fromJson(json);
        assessmentResponseModel = model;
        totalQuestions = model.questions?.length ?? 0;
        optionSelectionStatus = List.generate(
            totalQuestions,
            (index) => List.generate(
                model.questions?[index].answers?.length ?? 0,
                (index) => false));
      }
    }

    return assessmentResponseModel;
  }
}
