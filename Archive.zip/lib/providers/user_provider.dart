import 'package:flutter/cupertino.dart';
import 'package:illumine/mvvm/models/login_module/login_response_model.dart';

class UserProvider extends ChangeNotifier {
  User _user = User();

  User get user => _user;

  void setUser(User? user) {
    if (user != null) {
      _user = user;
    }
    notifyListeners();
  }
}
