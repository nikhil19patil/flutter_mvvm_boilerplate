import 'package:flutter/material.dart';
import 'package:illumine/main.dart';
import 'package:illumine/mvvm/views/assesment/assessment_screen.dart';
import 'package:illumine/mvvm/views/common/splash_screen.dart';
import 'package:illumine/mvvm/views/dashboard_module/dashboard_screen.dart';
import 'package:illumine/mvvm/views/login_module/forgot_password_screen.dart';
import 'package:illumine/mvvm/views/login_module/login_screen.dart';
import 'package:illumine/mvvm/views/login_module/register_screen.dart';
import 'package:illumine/src/core/value/Constants.dart';

class RouteConstants {
  static const kSplashScreen = "/splashScreen";
  static const String kLoginScreen = '/loginScreen';
  static const String kRegister = '/registerScreen';
  static const String kForgotPassword = '/forgotPasswordScreen';
  static const String kDashboard = '/dashboard';
  static const String kAssessmentScreen = '/assessmentScreen';
}

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    // Getting arguments passed in while calling Navigator.pushNamed
    final args = settings.arguments;

    switch (settings.name) {
      case RouteConstants.kSplashScreen:
        return MaterialPageRoute(builder: (_) => const SplashScreen());

      case RouteConstants.kLoginScreen:
        return MaterialPageRoute(builder: (_) => const LoginScreen());

      case RouteConstants.kRegister:
        return MaterialPageRoute(builder: (_) => const RegisterScreen());

      case RouteConstants.kForgotPassword:
        return MaterialPageRoute(builder: (_) => const ForgotPasswordScreen());

      case RouteConstants.kDashboard:
        return MaterialPageRoute(builder: (_) => const DashboardScreen());

      case RouteConstants.kAssessmentScreen:
        return MaterialPageRoute(builder: (_) => const AssesmentScreen());

      default:
        return _errorRoute();
    }
  }

  static Route<dynamic> _errorRoute() {
    return MaterialPageRoute(builder: (_) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Error'),
        ),
        body: const Center(
          child: Text('ERROR'),
        ),
      );
    });
  }
}
